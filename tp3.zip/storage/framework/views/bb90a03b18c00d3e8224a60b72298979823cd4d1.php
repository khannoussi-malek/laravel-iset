

    <?php $__env->startSection('color'); ?>
    pink
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('title'); ?>
    view 2 ranime
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('body'); ?>
    this is body of view2
    <?php $__env->stopSection(); ?>
<?php echo $__env->make("Template", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\malek\Desktop\test\resources\views/view2.blade.php ENDPATH**/ ?>