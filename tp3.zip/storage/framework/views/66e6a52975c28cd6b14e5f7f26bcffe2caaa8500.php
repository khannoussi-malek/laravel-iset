

    <?php $__env->startSection('title'); ?>
        affirche matt
    <?php $__env->stopSection(); ?>
    
    <?php $__env->startSection('table'); ?>
    <table class="table table-hover table-sm">
				<thead>
					<tr>
						<th>
                        Date  
						</th>
						<th>
                        Lieu  
						</th>
						<th>
                        Code 
						</th>
					</tr>
				</thead>
				<tbody>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
						<td>
                        <?php echo e($d->datepreuve); ?>

						</td>
						<td>
						<?php echo e($d->lieu); ?>

						</td>
						<td>
                        <?php echo e($d->numepreuve); ?>

						</td>
						
					</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</tbody>
			</table>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('Template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\malek\Desktop\test\resources\views/affepr.blade.php ENDPATH**/ ?>