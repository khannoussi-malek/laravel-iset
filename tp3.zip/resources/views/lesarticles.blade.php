<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>les articles</title>
</head>
<body>
    <h1>cest larticle numero n° {{$numero}}    </h1>
    
    <h1>cest larticle numero n° <?php echo $numero ?>    </h1>
</body>
</html>