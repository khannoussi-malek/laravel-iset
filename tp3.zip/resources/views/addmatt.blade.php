@extends('Template')

    @section('title')
        add matt
    @endsection
    
    @section('table')
        <form action="{{url()}}"></form>
    @endsection