<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class eprController extends Controller
{
    function affiche(){
        $epr= DB::table('epreuve')->get();
        return view('affepr')->with('data',$epr);
    }
}
