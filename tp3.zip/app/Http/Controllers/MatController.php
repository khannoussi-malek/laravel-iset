<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class MatController extends Controller
{
    function affiche(){
        $mat= DB::table('matiere')->get();
         return view('affMat')->with('data',$mat);
     }
     
}
