

    <?php $__env->startSection('color'); ?>
    blue
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('title'); ?>
    view1
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('body'); ?>
    this is body of view1
    <?php $__env->stopSection(); ?>
<?php echo $__env->make("Template", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\malek\Desktop\test\resources\views/view1.blade.php ENDPATH**/ ?>