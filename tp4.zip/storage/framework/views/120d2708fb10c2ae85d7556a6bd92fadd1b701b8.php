

    <?php $__env->startSection('title'); ?>
        add matt
    <?php $__env->stopSection(); ?>
    
    <?php $__env->startSection('table'); ?>
        <?php echo e(Form::open(array('url' => 'addmatiere'))); ?>

            <h1>hi</h1>
        <?php echo e(Form::close()); ?>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('Template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\malek\Desktop\test\resources\views/addmatt.blade.php ENDPATH**/ ?>