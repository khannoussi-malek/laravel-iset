

    <?php $__env->startSection('color'); ?>
    yellow
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('title'); ?>
    view 3
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('body'); ?>
    this is body of view3
    <?php $__env->stopSection(); ?>
<?php echo $__env->make("Template", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\malek\Desktop\test\resources\views/view3.blade.php ENDPATH**/ ?>